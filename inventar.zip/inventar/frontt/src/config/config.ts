export const config = {
    firebaseConfig: {
        apiKey: "AIzaSyAONLEyHUZRuNpeIHLeEdLx4-N2WsTMdb8",
        authDomain: "login-ad14b.firebaseapp.com",
        projectId: "login-ad14b",
        storageBucket: "login-ad14b.appspot.com",
        messagingSenderId: "199593319156",
        appId: "1:199593319156:web:137a4a4790943881c21ca1"
    }
  };