export interface ModalProps {
    id: string;
    label: string;
    title: string;
    body: string;
    handleAction: any;
    actionLabel?: string;
}