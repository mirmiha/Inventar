export interface ButtonSpinnerProps { text?: string | null }
