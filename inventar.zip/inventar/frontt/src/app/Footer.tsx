export const Footer = () => {
    return (
        <footer className="mt-2 py-3 bg-light">
            <div className="container-fluid">
            </div>
        </footer>
    )
}